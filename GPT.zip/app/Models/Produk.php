<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Produk extends Model
{
    protected $table = 'produk';
    
    protected $fillable = [
        'toko_id',
        'nama_produk',
        'deskripsi',
        'harga_nominal',
        'foto',
    ];
}
